-- 1) Feedback tarixi Rezervasiya cedvelindeki butun CheckInDate tarixlerden boyuk olan qonaqlar haqqinda melumatlar 

SELECT 
    g.GuestID, 
    g.FirstName, 
    g.LastName, 
    ar.AccommodationReservationID,
    a.AccommodationName,
	ar.CheckInDate,
	r.RoomType,
    f.FeedbackID, 
    f.Comments,
    f.FeedbackDateTime
FROM guest.Guests g
JOIN accommodation.AccommodationReservations ar ON g.GuestID = ar.GuestID
JOIN accommodation.Rooms r ON ar.RoomID = r.RoomID
JOIN accommodation.Accommodations a ON a.AccommodationID = r.AccommodationID
JOIN guest.Feedback f ON g.GuestID = f.GuestID
WHERE f.FeedbackDateTime >= ALL(
            SELECT 
	           arr.CheckInDate 
	        FROM accommodation.AccommodationReservations arr 
	   )
ORDER BY g.FirstName



-- 2) Rezervasiyasi olan her accommodation ucun toplam gelir  

SELECT 
       a.AccommodationID, 
	   a.AccommodationName,
	   a.CityID,
       SUM(ar.TotalAmount * cr.USD) AS TotalRevenue
FROM accommodation.Accommodations a
INNER JOIN accommodation.Rooms r ON r.AccommodationID = a.AccommodationID
INNER JOIN accommodation.AccommodationReservations ar ON r.RoomID = ar.RoomID
INNER JOIN accommodation.Currency c ON c.CurrencyID = ar.CurrencyID
INNER JOIN accommodation.CurrencyRate cr ON cr.CurrencyID = c.CurrencyID and cr.Date = '2023-06-01' 
GROUP BY a.AccommodationID , a.AccommodationName ,a.CityID
ORDER BY AccommodationName DESC;



-- 3) List of Accommodations with Specific Facilities,  for example ('Free WiFi','Spa','Business Center')

SELECT 
      a.AccommodationID,
	  a.AccommodationName,
	  f.FacilityName,
	  ROW_NUMBER() OVER (PARTITION BY a.AccommodationID ORDER BY a.AccommodationID) AS NumberOfSpesificFacilities
FROM accommodation.Accommodations a
INNER JOIN accommodation.AccommodationFacilities af ON a.AccommodationID = af.AccommodationID
INNER JOIN accommodation.Facilities f ON af.FacilityID = f.FacilityID
WHERE f.FacilityName = ANY( 
                              SELECT 
						          FacilityName
						      FROM accommodation.Facilities 
							  WHERE FacilityName IN ('Free WiFi','Spa','Business Center')
						)
GROUP BY a.AccommodationID, a.AccommodationName, f.FacilityName
ORDER BY a.AccommodationID;



-- 4) Aircraft tipine gore ucuslar haqqinda melumat

SELECT 
    f.FlightID,
    f.AircraftID,
    a.AircraftName,
    f.DepartureAirportID,
    f.ArrivalAirportID,
    f.GuestID,
    f.Stops,
	ROW_NUMBER () OVER (PARTITION BY a.AircraftName ORDER BY a.AircraftName) AS RowNumberForAircraftName
FROM flight.Flights f
JOIN flight.Aircrafts a ON f.AircraftID = a.AircraftID
WHERE a.AircraftType = (SELECT 
                             AircraftType 
                        FROM flight.Aircrafts 
                        WHERE AircraftID = 1
						)
ORDER BY a.AircraftName



-- 5) Get Average Rating of Accommodations for each City

WITH AverageRating AS (
SELECT 
       c.CityName,
	   a.AccommodationName,
	   AVG(s.AverageRating) AS AvgRating,
	   DENSE_RANK() OVER (ORDER BY AVG(s.AverageRating) DESC) AS RankValueForAvgRating
FROM accommodation.Accommodations a 
INNER JOIN accommodation.City c ON a.CityID = c.CityID
INNER JOIN guest.Scores s ON a.AccommodationID = s.AccommodationID
GROUP BY c.CityName, a.AccommodationName
)

SELECT 
       CityName, 
	   AccommodationName, 
	   AvgRating, 
	   RankValueForAvgRating 
FROM AverageRating
ORDER BY AvgRating DESC




-- 6) 2 defe AverageRating veren her musterinin verdiyi butun AverageRating - lerin ortalamasi ve buna esasen
--   'A' ile baslayan musterilerin feedback sayi

CREATE VIEW GuestFeedback
AS
SELECT 
    g.GuestID, 
    g.FirstName, 
    g.LastName,
    AVG(s.AverageRating) AS AvgRating
FROM guest.Guests g
INNER JOIN guest.Scores s ON g.GuestID = s.GuestID
GROUP BY g.GuestID, g.FirstName, g.LastName
HAVING COUNT(s.AverageRating) = 2

SELECT 
    gf.GuestID,
    gf.FirstName,
    gf.LastName,
    gf.AvgRating,
	COUNT(f.FeedbackID) AS Count
FROM GuestFeedback gf
JOIN guest.Feedback f ON f.GuestID = gf.GuestID
WHERE gf.FirstName LIKE 'A%'
GROUP BY gf.GuestID, gf.FirstName, gf.LastName, gf.AvgRating




-- 7) Reserved room's Accommodation with TypeName and Amount in first CTE and Total for each Type name

WITH RankedReservations AS (
    SELECT 
        ar.RoomID, 
        a.AccommodationName, 
        at.TypeName,
        DENSE_RANK() OVER (ORDER BY at.TypeName) AS DenseRank,
        ROW_NUMBER() OVER (PARTITION BY at.TypeName ORDER BY ar.RoomID) AS RowNumber,
        ar.TotalAmount * cr.USD AS ConvertedAmount
    FROM accommodation.AccommodationReservations ar
    INNER JOIN accommodation.Rooms r ON r.RoomID = ar.RoomID
    INNER JOIN accommodation.Accommodations a ON r.AccommodationID = a.AccommodationID
    LEFT JOIN accommodation.AccommodationTypes at ON at.AccommodationTypeID = a.AccommodationTypeID
    JOIN accommodation.Currency c ON c.CurrencyID = ar.CurrencyID
    JOIN accommodation.CurrencyRate cr ON c.CurrencyID = cr.CurrencyID
    WHERE cr.Date = '2024-07-01' AND at.TypeName IN ('Apartments', 'Hotels', 'Hostels')
) ,

AggregatedTotals AS (
    SELECT  
        TypeName,
        SUM(ConvertedAmount) AS Total
    FROM RankedReservations
    GROUP BY TypeName
)

SELECT 
    r.TypeName,
    ROUND(at.Total,2) AS TOTAL
FROM RankedReservations r
JOIN AggregatedTotals at ON r.TypeName = at.TypeName
GROUP BY  r.TypeName, at.Total
ORDER BY r.TypeName;




-- 8) List total revenue of Accommodations with All Room Types (standard, suite and deluxe)
SELECT 
        a.AccommodationID,
		a.AccommodationName,
		SUM(
		      CASE
			      WHEN ar.CurrencyID = 1 THEN ar.TotalAmount* cr.USD
		          WHEN ar.CurrencyID = 2 THEN ar.TotalAmount * cr.USD
			      ELSE ar.TotalAmount * cr.USD
	          END
	    ) as Total

FROM accommodation.Accommodations a
JOIN accommodation.Rooms r ON a.AccommodationID = r.AccommodationID
JOIN accommodation.AccommodationReservations ar ON ar.RoomID = r.RoomID
JOIN accommodation.Currency c ON c.CurrencyID = ar.CurrencyID
JOIN accommodation.CurrencyRate cr ON c.CurrencyID = cr.CurrencyID
WHERE cr.Date ='2024-06-01' 
GROUP BY a.AccommodationID, a.AccommodationName
HAVING COUNT(DISTINCT r.RoomType) = 3
ORDER BY a.AccommodationName;




-- 9) Find Flights with Highest Ticket Price

WITH FlightPrices AS (
    SELECT 
        f.FlightID, 
        c.ShortName AS Currency,
        fp.Price, 
        cr.AZN,
        ROUND(fp.Price * cr.AZN,2) as Total
    FROM flight.Flights f
    INNER JOIN flight.FlightPrice fp ON f.FlightID = fp.FlightID
    INNER JOIN accommodation.Currency c ON fp.CurrencyID = c.CurrencyID
    INNER JOIN accommodation.CurrencyRate cr ON cr.CurrencyID = c.CurrencyID
    WHERE cr.Date = '2023-06-01'
)
SELECT 
    FlightID, 
    Currency,
    Price, 
    AZN,
    Total
FROM FlightPrices
ORDER BY Price DESC
OFFSET 5 ROWS FETCH NEXT 10 ROWS ONLY;



-- 10) List Guests with Reservations in a Specific Date Range and Their Total Spending:

SELECT 
       g.GuestID, 
	   g.FirstName,
	   g.LastName,
	   SUM(ar.TotalAmount * cr.EURO) AS TotalSpending
FROM guest.Guests g
INNER JOIN accommodation.AccommodationReservations ar ON g.GuestID = ar.GuestID
INNER JOIN accommodation.CurrencyRate cr ON ar.CurrencyID = cr.CurrencyID  
WHERE cr.Date = '2024-06-01' AND ar.CheckInDate BETWEEN '2024-06-01' AND '2024-06-10'
GROUP BY g.GuestID, g.FirstName, g.LastName
ORDER BY TotalSpending DESC;



-- 11) Calculate the number of reserved guests, grouped by the country  

WITH GuestCountry AS(
     SELECT
             co.CountryName, 
	         COUNT(ar.GuestID) AS NumberOfGuests,
			 DENSE_RANK() OVER (ORDER BY COUNT(ar.GuestID)) AS RankValue
      FROM guest.Guests g
	  INNER JOIN accommodation.AccommodationReservations ar ON ar.GuestID = g.GuestID
      INNER JOIN accommodation.City ci ON g.CityID = ci.CityID
      INNER JOIN accommodation.Country co ON ci.CountryID = co.CountryID
      GROUP BY co.CountryName
)

SELECT 
    CountryName, 
	NumberOfGuests,
	DENSE_RANK() OVER (ORDER BY NumberOfGuests DESC) AS RankValue
FROM GuestCountry
ORDER BY NumberOfGuests DESC;




-- 12) Calculate the total and average revenue generated by each accommodation type according to CurrencyType

SELECT 
       at.TypeName,
	   ar.CurrencyID,
	   SUM(ar.TotalAmount * cr.USD) AS TotalRevenueUSD,
       AVG(ar.TotalAmount * cr.USD) AS AvgRevenueUSD
FROM accommodation.AccommodationTypes at
JOIN accommodation.Accommodations a ON at.AccommodationTypeID = a.AccommodationTypeID
JOIN accommodation.Rooms r ON r.AccommodationID = a.AccommodationID
JOIN accommodation.AccommodationReservations ar ON r.RoomID = ar.RoomID
JOIN accommodation.Currency c ON ar.CurrencyID = c.CurrencyID
JOIN accommodation.CurrencyRate cr ON cr.CurrencyID = c.CurrencyID
WHERE cr.Date ='2024-06-01'
GROUP BY at.TypeName,ar.CurrencyID
ORDER BY at.TypeName;



-- 13) Find reason, CustomStatus and StatusCode for all flights    

SELECT 
      f.FlightID,
	  fs.StatusName, 
	  fr.ReasonText,
	   CASE
          WHEN fs.StatusName = 'Scheduled' THEN 'Flight is scheduled'
          WHEN fs.StatusName = 'On Time' THEN 'Flight is on time'
          WHEN fs.StatusName = 'Delayed' THEN 'Flight is delayed'
          WHEN fs.StatusName = 'Arrived' THEN 'Flight has arrived'
          WHEN fs.StatusName = 'Cancelled' THEN 'Flight is cancelled'
          ELSE 'Unknown status'
      END AS CustomStatus,
      CASE
          WHEN fs.StatusName = 'Scheduled' THEN 'S'
          WHEN fs.StatusName = 'On Time' THEN 'OT'
          WHEN fs.StatusName = 'Delayed' THEN 'D'
          WHEN fs.StatusName = 'Arrived' THEN 'A'
          WHEN fs.StatusName = 'Cancelled' THEN 'C'
          ELSE 'U'
      END AS StatusCode
FROM flight.Flights f
JOIN flight.FlightStatusReason fsr ON  fsr.StatusReasonID = f.StatusReasonID
JOIN flight.FlightStatus fs ON fsr.FlightStatusID = fs.FlightStatusID
JOIN flight.FlightReason fr ON fsr.FlightReasonID = fr.FlightReasonID



-- 14)  Retrieve facility name, usage count for each accommodations start the letter 'U' (eyni adda bir nece accommodation ola biler)

WITH CTE AS(
       SELECT 
	       f.FacilityName, 
		   a.AccommodationName,
		   COUNT(af.FacilityID) AS UsageCount
       FROM accommodation.AccommodationFacilities af
       JOIN accommodation.Facilities f ON af.FacilityID = f.FacilityID
	   JOIN accommodation.Accommodations a ON a.AccommodationID = af.AccommodationID
       GROUP BY f.FacilityName, a.AccommodationName
)
SELECT 
       FacilityName, 
	   AccommodationName,
	   UsageCount
FROM CTE
WHERE AccommodationName LIKE 'U%'
ORDER BY FacilityName;



-- 15) Find the cities traveled by more than 2 guests

SELECT    
	   ci.CityID,
	   ci.CityName,
	   co.CountryID,
	   co.CountryName,
	   COUNT(ar.GuestID) as GuestCount
FROM guest.Guests g
JOIN accommodation.AccommodationReservations ar ON g.GuestID = ar.GuestID
JOIN accommodation.Rooms r ON ar.RoomID = r.RoomID
JOIN accommodation.Accommodations a ON r.AccommodationID = a.AccommodationID
JOIN accommodation.City ci ON a.CityID = ci.CityID
JOIN accommodation.Country co ON ci.CountryID = co.CountryID
GROUP BY ci.CityID, co.CountryID, co.CountryName, ci.CityName
HAVING COUNT(ar.GuestID) > 2
ORDER BY co.CountryName
OFFSET 10 ROWS FETCH NEXT 100 ROWS ONLY;



-- 16) Calculate the maximum ticket price for each activity inside CTE

WITH MaxTicketPrices AS (
    SELECT 
        a.ActivityName,
        t.CurrencyID,
        MAX(t.TicketPrice) AS MaxPrice
    FROM accommodation.Activities a
    JOIN accommodation.[Transaction] t ON a.ActivityID = t.ActivityID
    GROUP BY a.ActivityName, t.CurrencyID
)

SELECT 
    mtp.ActivityName,
    c.Shortname,
    CASE
        WHEN mtp.CurrencyID = 1 THEN mtp.MaxPrice * cr.AZN
        WHEN mtp.CurrencyID = 2 THEN mtp.MaxPrice * cr.AZN
        ELSE mtp.MaxPrice 
    END AS TicketPrice
    --CASE
    --    WHEN mtp.CurrencyID = 1 THEN 'AZN'
    --    WHEN mtp.CurrencyID = 2 THEN 'USD'
    --    ELSE 'EURO'
    --END AS CurrencyType
FROM MaxTicketPrices mtp
JOIN accommodation.Currency c ON mtp.CurrencyID = c.CurrencyID
JOIN accommodation.CurrencyRate cr ON cr.CurrencyID = c.CurrencyID
WHERE cr.Date = '2024-06-01'
ORDER BY mtp.ActivityName;



-- 17) Guests Feedback count

WITH GuestComments AS (
    SELECT
        g.FirstName,
        g.LastName,
        COUNT(*) AS CountOfComments
    FROM guest.Guests g
    JOIN guest.Feedback f ON f.GuestID = g.GuestID
    GROUP BY g.FirstName, g.LastName
)
SELECT
    gc.FirstName,
    gc.LastName,
    gc.CountOfComments,
    ROW_NUMBER() OVER (PARTITION BY gc.CountOfComments ORDER BY gc.CountOfComments, gc.FirstName, gc.LastName) AS RowNumber
FROM GuestComments gc
ORDER BY gc.CountOfComments, gc.FirstName, gc.LastName;



-- 18)  -- Flight informattion with subquery

SELECT 
    f.FlightID,
    f.DepartureAirportID,
    f.ArrivalAirportID,
    f.GuestID,
	CONCAT(g.FirstName , ' ' , g.LastName) AS GuestName,
    (SELECT Price FROM flight.FlightPrice WHERE FlightID = f.FlightID) AS Price,
    (SELECT CurrencyID FROM flight.FlightPrice WHERE FlightID = f.FlightID) AS CurrencyID,
    da.AirportName AS DepartureAirport,
    aa.AirportName AS ArrivalAirport,
    fs.StatusName AS FlightStatus
FROM flight.Flights f
JOIN flight.Airports da ON f.DepartureAirportID = da.AirportID
JOIN flight.Airports aa ON f.ArrivalAirportID = aa.AirportID
JOIN guest.Guests g ON f.GuestID = g.GuestID
JOIN flight.FlightStatus fs ON f.StatusReasonID = fs.FlightStatusID
ORDER BY CONCAT(g.FirstName , ' ' , g.LastName)



-- 19) Find sum of rooms each accommodations that are fully booked ( is not available) and 
--     union sum of rooms each accommodations that are is available on a specific date

SELECT 
       a.AccommodationID,
       a.AccommodationName,
	   COUNT(r.RoomID) AS SumOfRooms
FROM accommodation.Accommodations a
JOIN accommodation.Rooms r ON a.AccommodationID = r.AccommodationID
JOIN accommodation.RoomAvailability ra ON r.RoomID = ra.RoomID
WHERE ra.Date = '2024-06-01' AND ra.IsAvailable = 0
GROUP BY a.AccommodationID, a.AccommodationName

UNION ALL

SELECT 
       a.AccommodationID,
       a.AccommodationName,
	   COUNT(r.RoomID) AS SumOfRooms
FROM accommodation.Accommodations a
JOIN accommodation.Rooms r ON a.AccommodationID = r.AccommodationID
JOIN accommodation.RoomAvailability ra ON r.RoomID = ra.RoomID
WHERE ra.Date = '2024-06-01' AND ra.IsAvailable = 1
GROUP BY a.AccommodationID, a.AccommodationName


----------------------------------------------------------------------------------------------------------------------------------

--Function example

CREATE FUNCTION dbo.GetFlightScheduleDetails (@ScheduleDate DATE)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        fs.FlightScheduleID,
        f.FlightID,
        a.AircraftName,
        arrAirport.AirportName AS DepartureAirport,
        arrAirport.CityID AS DepartureCityID,
        fs.ArrivalTime,
        DATEDIFF(HOUR, fs.DepartureTime, fs.ArrivalTime) AS DurationHours,
        ft.TerminalName AS FlightTerminal
    FROM flight.FlightSchedule fs
    JOIN flight.Flights f ON fs.FlightID = f.FlightID
    JOIN flight.Aircrafts a ON f.AircraftID = a.AircraftID
    JOIN flight.FlightTerminals ft ON fs.FlightTerminalID = ft.FlightTerminalID
    JOIN  flight.Airports arrAirport ON f.DepartureAirportID = arrAirport.AirportID
    WHERE 
        CAST(fs.ArrivalTime AS DATE) = @ScheduleDate
);

SELECT * FROM dbo.GetFlightScheduleDetails('2024-06-02');

select * from flight.FlightSchedule

-----------------------------------------------------------------------------------------------------------------------------------------------------------

-- View Examples

--  1)  Flight with status and reason

CREATE VIEW FlightDetailsView
AS
SELECT 
    f.FlightID,
    fs.FlightStatusID,
    fs.StatusName,
    fr.ReasonText
FROM flight.Flights f
INNER JOIN flight.FlightStatusReason fsr ON fsr.StatusReasonID = f.StatusReasonID
INNER JOIN flight.FlightStatus fs ON fs.FlightStatusID = fsr.FlightStatusID
LEFT JOIN flight.FlightReason fr ON fr.FlightReasonID = fsr.FlightReasonID;

SELECT 
    ReasonText AS DelayReason,
	COUNT(ReasonText) AS REASON
FROM FlightDetailsView
WHERE StatusName = 'Delayed'
GROUP BY  ReasonText


-- 2) Calculate the average ticket price and total amount for each activity

CREATE VIEW ActivityTransactionSummary 
AS
SELECT 
      a.ActivityName,
	  AVG(t.TicketPrice) AS AvgTicketPrice,
	  SUM(t.TotalAmount * cr.USD) AS Total

FROM accommodation.Activities a
JOIN accommodation.[Transaction] t ON a.ActivityID = t.ActivityID
JOIN accommodation.Currency c ON t.CurrencyID = c.CurrencyID
JOIN accommodation.CurrencyRate cr ON cr.CurrencyID = c.CurrencyID
WHERE cr.Date ='2024-06-01'
GROUP BY a.ActivityName;

SELECT * FROM ActivityTransactionSummary 



-- 3) Find informations about top 10 accommodations

CREATE VIEW TopAccommodations
AS
SELECT 
    AccommodationID,
    AccommodationName,
    CityID,
    AccommodationTypeID
FROM accommodation.Accommodations
WHERE AccommodationID IN (
    SELECT TOP 10 
	      AccommodationID
    FROM accommodation.Accommodations
    ORDER BY AccommodationID DESC
);

SELECT * FROM TopAccommodations




-- 4) Karti olan musterilerin 2-ci ucuslarini qaytarir

CREATE VIEW GuestCardType
AS
SELECT 
       g.GuestID,
	   g.FirstName, 
	   g.LastName, 
	   ct.CardTypeName,
	   ROW_NUMBER () OVER (PARTITION BY ct.CardTypeID ORDER BY ct.CardTypeID) AS RowNumber
FROM guest.Guests g
JOIN guest.Card c ON g.GuestID = c.GuestID
JOIN guest.CardTypes ct ON ct.CardTypeID = c.CardTypeID

WITH GuestFlights AS (
    SELECT 
        gct.GuestID,
        gct.FirstName,
        gct.LastName,
        f.FlightID,
        ROW_NUMBER() OVER (PARTITION BY gct.GuestID ORDER BY f.FlightID) AS FlightRowNum
    FROM GuestCardType gct
    JOIN flight.Flights f ON gct.GuestID = f.GuestID
)

SELECT 
    GuestID,
    FirstName,
    LastName,
    FlightID
FROM GuestFlights
WHERE FlightRowNum = 1;

