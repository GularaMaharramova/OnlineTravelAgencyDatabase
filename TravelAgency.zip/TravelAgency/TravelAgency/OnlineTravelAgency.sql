--Create database OnlineTravelAgency
--Create schema flight
--Create schema accommodation
--Create schema guest

USE OnlineTravelAgency
GO

CREATE TABLE accommodation.Country (
    CountryID INT PRIMARY KEY,
    CountryName NVARCHAR(100) NOT NULL
);

SELECT * FROM accommodation.Country

-----

CREATE TABLE accommodation.City (
    CityID INT PRIMARY KEY,
    CityName NVARCHAR(100) NOT NULL,
    CountryID INT,
    CONSTRAINT FK_City_Country FOREIGN KEY (CountryID) REFERENCES accommodation.Country(CountryID)
);

SELECT * FROM accommodation.City

-----

CREATE TABLE guest.Guests (
    GuestID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    SerialNumber VARCHAR(200) UNIQUE,
    Gender VARCHAR(10),
    PhoneNumber VARCHAR(20),
    CityID INT,
    CONSTRAINT FK_Guests_City FOREIGN KEY (CityID) REFERENCES accommodation.City(CityID)
);

SELECT * FROM guest.Guests

-----

CREATE TABLE guest.LogIn (
    LogInID INT PRIMARY KEY IDENTITY(1,1), 
	GuestID INT NULL,
    Username VARCHAR(40) NOT NULL,
    Password VARCHAR(20) NOT NULL,  -- UNIQUE
    LogInDate DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_LogIn_Guest FOREIGN KEY (GuestID) REFERENCES guest.Guests(GuestID),
    CONSTRAINT CK_Password_Strength CHECK (
        Password LIKE '%[A-Z]%' AND  -- Contains at least one uppercase letter
        Password LIKE '%[a-z]%' AND  -- Contains at least one lowercase letter
        Password LIKE '%[0-9]%' AND  -- Contains at least one digit
        Password LIKE '%[^a-zA-Z0-9]%'  -- Contains at least one special character
    )
);

SELECT * FROM guest.LogIn

-----

CREATE TABLE guest.CardTypes (
    CardTypeID INT PRIMARY KEY,
    CardTypeName VARCHAR(50) NOT NULL
);

SELECT * FROM guest.CardTypes 

-----

CREATE TABLE guest.Card (
    CardID INT PRIMARY KEY IDENTITY(1,1),
    CardNumber VARCHAR(20) NOT NULL UNIQUE,
    GuestID INT,
    CreatedDate DATE NOT NULL,
    ExpiryDate DATE NOT NULL,
    Fee DECIMAL(10, 2) NOT NULL,
    CardTypeID INT,
    CONSTRAINT FK_Card_Guest FOREIGN KEY (GuestID) REFERENCES guest.Guests(GuestID),
	CONSTRAINT FK_Card_CardType FOREIGN KEY (CardTypeID) REFERENCES guest.CardTypes(CardTypeID)
);

SELECT * FROM  guest.Card

-----

CREATE TABLE accommodation.AccommodationTypes (
    AccommodationTypeID INT PRIMARY KEY,
    TypeName NVARCHAR(50) NOT NULL,
    Description NVARCHAR(255)
);

SELECT * FROM accommodation.AccommodationTypes

-----

CREATE TABLE accommodation.Accommodations (
    AccommodationID INT PRIMARY KEY,
    AccommodationTypeID INT NOT NULL,
    AccommodationName NVARCHAR(100) NOT NULL,
    CityID INT,
    CONSTRAINT FK_Accommodations_City FOREIGN KEY (CityID) REFERENCES accommodation.City(CityID),
    CONSTRAINT FK_Accommodations_AccommodationType FOREIGN KEY (AccommodationTypeID) REFERENCES accommodation.AccommodationTypes(AccommodationTypeID)
);

SELECT * FROM accommodation.Accommodations

-----

CREATE TABLE accommodation.NeighborhoodNames (
    NeighborhoodID INT PRIMARY KEY,
    NeighborhoodName VARCHAR(100) NOT NULL
);

SELECT * FROM accommodation.NeighborhoodNames

-----

CREATE TABLE accommodation.Neighborhoods (
    NeighborhoodID INT,
    AccommodationID INT,
    PRIMARY KEY (NeighborhoodID, AccommodationID),
    CONSTRAINT FK_Neighborhoods_Accommodation FOREIGN KEY (AccommodationID) REFERENCES accommodation.Accommodations(AccommodationID),
    CONSTRAINT FK_Neighborhoods_Neighborhood FOREIGN KEY (NeighborhoodID) REFERENCES accommodation.NeighborhoodNames(NeighborhoodID)
);

SELECT * FROM accommodation.Neighborhoods 

-----

CREATE TABLE accommodation.Rooms (
    RoomID INT PRIMARY KEY,
    AccommodationID INT NOT NULL,
    RoomNumber VARCHAR(20) NOT NULL,
    RoomType NVARCHAR(50) NOT NULL,
    PricePerNight DECIMAL(5, 2) NOT NULL,
    Capacity INT NOT NULL,
    IsAvailable BIT DEFAULT 1,   -- 1 yes,  0 no
    CONSTRAINT FK_Rooms_Accommodation FOREIGN KEY (AccommodationID) REFERENCES accommodation.Accommodations(AccommodationID)
);

select * from accommodation.Rooms

-----

CREATE TABLE accommodation.Accessibilities (
    AccessibilityID INT PRIMARY KEY,
    AccessibilityName NVARCHAR(100) NOT NULL
);

SELECT * FROM accommodation.Accessibilities 

-----

CREATE TABLE accommodation.RoomAccessibilities (
    RoomID INT NOT NULL,
    AccessibilityID INT NOT NULL,
    CONSTRAINT FK_RoomAccessibilities_Room FOREIGN KEY (RoomID) REFERENCES accommodation.Rooms(RoomID),
    CONSTRAINT FK_RoomAccessibilities_Accessibility FOREIGN KEY (AccessibilityID) REFERENCES accommodation.Accessibilities(AccessibilityID),
    PRIMARY KEY (RoomID, AccessibilityID)
);

SELECT * FROM accommodation.RoomAccessibilities 

-----

CREATE TABLE accommodation.RoomAvailability (
    RoomID INT NOT NULL,
    IsAvailable BIT NOT NULL,
    Date DATE,
    CONSTRAINT FK_RoomAvailability_Room FOREIGN KEY (RoomID) REFERENCES accommodation.Rooms(RoomID)
);

SELECT * FROM accommodation.RoomAvailability 

-----

CREATE TABLE accommodation.Activities (
    ActivityID INT PRIMARY KEY,
    ActivityName NVARCHAR(100) NOT NULL
);

SELECT * FROM accommodation.Activities

-----

CREATE TABLE accommodation.[Transaction] (
    TransactionID INT PRIMARY KEY,
    AccommodationID INT NOT NULL,
    ActivityID INT NOT NULL,
    NumberOfGuests INT NOT NULL,
    TransactionDateTime DATE,
    TicketPrice DECIMAL(10, 2) NOT NULL,
    TotalAmount DECIMAL(10, 2),
    CONSTRAINT FK_Transaction_Accommodation FOREIGN KEY (AccommodationID) REFERENCES accommodation.Accommodations(AccommodationID),
    CONSTRAINT FK_Transaction_Activity FOREIGN KEY (ActivityID) REFERENCES accommodation.Activities(ActivityID)
);

SELECT * FROM accommodation.[Transaction] 

-----

CREATE TABLE accommodation.TaxFeeName (
    TaxFeeNameID INT PRIMARY KEY,
    TaxFeeName NVARCHAR(100) NOT NULL
);

SELECT * FROM accommodation.TaxFeeName 

-----

CREATE TABLE accommodation.TaxFees (
    TaxFeesID INT PRIMARY KEY,
    AccommodationID INT NOT NULL,
    TaxFeeNameID INT,
    TaxFeePercentage DECIMAL(5, 2) NOT NULL,
    CONSTRAINT FK_TaxFees_Accommodation FOREIGN KEY (AccommodationID) REFERENCES accommodation.Accommodations(AccommodationID),
	CONSTRAINT FK_TaxFees_TaxFeeName FOREIGN KEY (TaxFeeNameID) REFERENCES accommodation.TaxFeeName(TaxFeeNameID),
	CONSTRAINT CK_TaxFees_TaxFeePercentage CHECK (TaxFeePercentage BETWEEN 0 AND 10)
);

SELECT * FROM accommodation.TaxFees 

-----

CREATE TABLE accommodation.Facilities (
    FacilityID INT PRIMARY KEY,
    FacilityName NVARCHAR(100) NOT NULL
);

SELECT * FROM accommodation.Facilities

-----

CREATE TABLE accommodation.AccommodationFacilities (
    AccommodationID INT NOT NULL,
    FacilityID INT NOT NULL,
    CONSTRAINT FK_AccommodationFacilities_Accommodation FOREIGN KEY (AccommodationID) REFERENCES accommodation.Accommodations(AccommodationID),
    CONSTRAINT FK_AccommodationFacilities_Facility FOREIGN KEY (FacilityID) REFERENCES accommodation.Facilities(FacilityID),
    PRIMARY KEY (AccommodationID, FacilityID)
);

SELECT * FROM accommodation.AccommodationFacilities 

-----

CREATE TABLE accommodation.Currency (
    CurrencyID INT PRIMARY KEY,
    ShortName VARCHAR(10) NOT NULL,
    LongName NVARCHAR(100) NOT NULL
);

SELECT * FROM accommodation.Currency

-----

CREATE TABLE accommodation.CurrencyRate (
    CurrencyRateID INT PRIMARY KEY,
    CurrencyID INT NOT NULL,
    Date DATETIME NOT NULL,
    USD DECIMAL(10, 4) NOT NULL,
    AZN DECIMAL(10, 4) NOT NULL,
    TL DECIMAL(10, 4) NOT NULL,
    EURO DECIMAL(10, 4) NOT NULL,
    CONSTRAINT FK_CurrencyRate_Currency FOREIGN KEY (CurrencyID) REFERENCES accommodation.Currency(CurrencyID)
);

SELECT * FROM accommodation.CurrencyRate

-----

CREATE TABLE accommodation.ReservationStatus (
    ReservationStatusID INT PRIMARY KEY,
    StatusName NVARCHAR(50) NOT NULL
);

SELECT * FROM accommodation.ReservationStatus

-----

CREATE TABLE accommodation.ReservationReason (
    ReservationReasonID INT PRIMARY KEY,
    ReasonText NVARCHAR(255)
);

SELECT * FROM accommodation.ReservationReason

-----

CREATE TABLE accommodation.ReservationStatusReason (
    StatusReasonID INT PRIMARY KEY,
	ReservationStatusID INT,
	ReservationReasonID INT,
	CONSTRAINT FK_ReservationStatusReason_ReservationStatus FOREIGN KEY(ReservationStatusID) REFERENCES accommodation.ReservationStatus(ReservationStatusID),
	CONSTRAINT FK_ReservationStatusReason_ReservationReason FOREIGN KEY(ReservationReasonID) REFERENCES accommodation.ReservationReason(ReservationReasonID)
);

SELECT * FROM accommodation.ReservationStatusReason

-----

CREATE TABLE accommodation.AccommodationReservations (
    AccommodationReservationID INT PRIMARY KEY,
    GuestID INT NOT NULL,
    RoomID INT NOT NULL,
    CheckInDate DATE NOT NULL,
    CheckOutDate DATE NOT NULL,
    DifferenceTime INT,  
    TotalAmount DECIMAL(10, 2) NOT NULL,
    BreakfastIncluded BIT,  -- 1 for included, 0 for not included
    DinnerIncluded BIT,     -- 1 for included, 0 for not included
	ReservationStatusID INT,   -- I altered this column' s name in next steps
    CurrencyID INT NOT NULL,
    CONSTRAINT FK_AccommodationReservations_Guest FOREIGN KEY (GuestID) REFERENCES guest.Guests(GuestID),
    CONSTRAINT FK_AccommodationReservations_Room FOREIGN KEY (RoomID) REFERENCES accommodation.Rooms(RoomID),  
    CONSTRAINT FK_AccommodationReservations_ReservationStatus FOREIGN KEY (ReservationStatusID) REFERENCES accommodation.ReservationStatus(ReservationStatusID),
    CONSTRAINT FK_AccommodationReservations_Currency FOREIGN KEY (CurrencyID) REFERENCES accommodation.Currency(CurrencyID)
);

-- Drop the foreign key constraint FK_AccommodationReservations_ReservationStatus
ALTER TABLE accommodation.AccommodationReservations
DROP CONSTRAINT FK_AccommodationReservations_ReservationStatus;

-- Rename the column ReservationStatusID to NewColumnName (replace with the desired new name)
EXEC sp_rename 'accommodation.AccommodationReservations.ReservationStatusID', 'StatusReasonID', 'COLUMN';

ALTER TABLE accommodation.AccommodationReservations
ADD CONSTRAINT FK_AccommodationReservations_StatusReason
FOREIGN KEY (StatusReasonID) REFERENCES accommodation.ReservationStatusReason(StatusReasonID);


SELECT * FROM accommodation.AccommodationReservations

-----

CREATE TABLE flight.Airlines (
    AirlineID INT PRIMARY KEY,
    AirlineName NVARCHAR(100) NOT NULL,
    CountryID INT,
    CONSTRAINT FK_Airlines_Country FOREIGN KEY (CountryID) REFERENCES accommodation.Country(CountryID)
);

SELECT * FROM flight.Airlines

-----

CREATE TABLE flight.Airports (
    AirportID INT PRIMARY KEY,
    AirportCode VARCHAR(10) NOT NULL,
    AirportName NVARCHAR(100) NOT NULL,
    CityID INT,
    [Address] VARCHAR(255),
    TelNumber VARCHAR(20),
    CONSTRAINT FK_Airports_City FOREIGN KEY (CityID) REFERENCES accommodation.City(CityID),
);

SELECT * FROM flight.Airports 

-----

CREATE TABLE flight.FlightStatus (
    FlightStatusID INT PRIMARY KEY,
    StatusName NVARCHAR(50) NOT NULL
);

SELECT * FROM flight.FlightStatus

-----

CREATE TABLE flight.FlightReason (
    FlightReasonID INT PRIMARY KEY,
    ReasonText NVARCHAR(255)
);

SELECT * FROM flight.FlightReason

-----

CREATE TABLE flight.FlightStatusReason (
    StatusReasonID INT PRIMARY KEY,
    FlightStatusID INT,
    FlightReasonID INT,
    CONSTRAINT FK_FlightStatusReason_FlightStatus FOREIGN KEY (FlightStatusID) REFERENCES flight.FlightStatus(FlightStatusID),
    CONSTRAINT FK_FlightStatusReason_FlightReason FOREIGN KEY (FlightReasonID) REFERENCES flight.FlightReason(FlightReasonID)
);

SELECT * FROM flight.FlightStatusReason;

-----

CREATE TABLE flight.Aircrafts (
    AircraftID INT PRIMARY KEY,
    AircraftName NVARCHAR(100) NOT NULL,
    AircraftType NVARCHAR(50) NOT NULL,
    Capacity INT NOT NULL,
    Speed INT NOT NULL,
    FirstFlightDay DATE,
    LastFlightDay DATE
);

SELECT * FROM flight.Aircrafts 

-----

CREATE TABLE flight.Flights (
    FlightID INT PRIMARY KEY,
    -- AirlineID INT NOT NULL,
    AircraftID INT NOT NULL,
    DepartureAirportID INT NOT NULL,
    ArrivalAirportID INT NOT NULL,
	GuestID INT NOT NULL,
	FlightStatusID INT NOT NULL,
    Stops INT DEFAULT 0,
    -- CONSTRAINT FK_Flights_Airline FOREIGN KEY (AirlineID) REFERENCES flight.Airlines(AirlineID),
    CONSTRAINT FK_Flights_Aircraft FOREIGN KEY (AircraftID) REFERENCES flight.Aircrafts(AircraftID),
    CONSTRAINT FK_Flights_DepartureAirport FOREIGN KEY (DepartureAirportID) REFERENCES flight.Airports(AirportID),
    CONSTRAINT FK_Flights_ArrivalAirport FOREIGN KEY (ArrivalAirportID) REFERENCES flight.Airports(AirportID),
	CONSTRAINT FK_Flights_Guest FOREIGN KEY (GuestID) REFERENCES guest.Guests(GuestID),
	CONSTRAINT FK_Flights_FlightStatus FOREIGN KEY (FlightStatusID) REFERENCES flight.FlightStatus(FlightStatusID)
);

SELECT * FROM flight.Flights

-----


-- created for easily data insert from accommodation.Currency table
CREATE TABLE accommodation.CurrencyMain (
    CurID INT PRIMARY KEY IDENTITY(1,1),
	CurrencyID INT,
    CONSTRAINT FK_CurrencyMain_Currency FOREIGN KEY (CurrencyID) REFERENCES accommodation.Currency(CurrencyID),
);

SELECT * FROM accommodation.CurrencyMain

-----

CREATE TABLE flight.FlightPrice (
    FlightPriceID INT PRIMARY KEY,
    FlightID INT NOT NULL,
    Price DECIMAL(10, 2),
    CurrencyID INT ,
    CONSTRAINT FK_FlightPrice_Flight FOREIGN KEY (FlightID) REFERENCES flight.Flights(FlightID),
	CONSTRAINT FK_FlightPrice_Currency FOREIGN KEY (CurrencyID) REFERENCES accommodation.Currency(CurrencyID),
);

SELECT * FROM flight.FlightPrice

-----

CREATE TABLE flight.FlightTerminals (
    FlightTerminalID INT PRIMARY KEY,
    AirportID INT NOT NULL,
    TerminalName VARCHAR(100) NOT NULL,
    CONSTRAINT FK_FlightTerminals_Airport FOREIGN KEY (AirportID) REFERENCES flight.Airports(AirportID)
);

SELECT * FROM flight.FlightTerminals

-----

CREATE TABLE flight.FlightSchedule (
    FlightScheduleID INT PRIMARY KEY,
    FlightID INT NOT NULL,
    DepartureTime DATETIME NOT NULL,
    ArrivalTime DATETIME NOT NULL,
    Duration TIME,
    FlightTerminalID INT, 
    CONSTRAINT FK_FlightSchedule_Flight FOREIGN KEY (FlightID) REFERENCES flight.Flights(FlightID),
    CONSTRAINT FK_FlightSchedule_FlightTerminal FOREIGN KEY (FlightTerminalID) REFERENCES flight.FlightTerminals(FlightTerminalID) 
);

ALTER TABLE flight.FlightSchedule DROP COLUMN Duration 
ALTER TABLE flight.FlightSchedule ADD Duration TIME

SELECT * FROM flight.FlightSchedule

-----

CREATE TABLE guest.Feedback (
    FeedbackID INT PRIMARY KEY IDENTITY(1,1),
    GuestID INT NOT NULL,
    FlightID INT,
    AccommodationID INT,
    Comments TEXT,
    FeedbackDateTime DATETIME ,
    CONSTRAINT FK_Feedback_Guest FOREIGN KEY (GuestID) REFERENCES guest.Guests(GuestID),
    CONSTRAINT FK_Feedback_Flight FOREIGN KEY (FlightID) REFERENCES flight.Flights(FlightID),
    CONSTRAINT FK_Feedback_Accommodation FOREIGN KEY (AccommodationID) REFERENCES accommodation.Accommodations(AccommodationID)
);
 
SELECT * FROM guest.Feedback

-----

CREATE TABLE guest.Scores (
    ScoreID INT PRIMARY KEY IDENTITY(1,1),
    GuestID INT NOT NULL,
    FlightID INT,
    AccommodationID INT,
    ScoreDateTime DATETIME ,
    AverageRating DECIMAL(2, 1),
    CONSTRAINT FK_Scores_Guest FOREIGN KEY (GuestID) REFERENCES guest.Guests(GuestID),
    CONSTRAINT FK_Scores_Flight FOREIGN KEY (FlightID) REFERENCES flight.Flights(FlightID),
    CONSTRAINT FK_Scores_Accommodation FOREIGN KEY (AccommodationID) REFERENCES accommodation.Accommodations(AccommodationID)
);

SELECT * FROM guest.Scores

